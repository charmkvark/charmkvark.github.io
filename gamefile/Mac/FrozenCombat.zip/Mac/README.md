

# Guide Zoom Online Play

**This guide will help you set up your online play environment given that one of the players already have                       downloaded and installed the game:**

### Step 1.

**Host:** start the game and share your screen in the Zoom room

### Step 2.

**Participant:** click **View Options** dropdown menu located at the top of your in-meeting window

Select **Request Remote Control**, then click **Request** to confirm

### Step 3.

The host will get a notification asking for this control request

Click **Approve**

### Step 4.

**Participant:** click inside the screen share to start controlling the host's screen

## **All done! Both of you can now play against one another on the same keyboard!**